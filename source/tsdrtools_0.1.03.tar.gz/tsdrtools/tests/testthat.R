library(testthat)
library(tsdrtools)

test_check("tsdrtools")

# covr::zero_coverage(covr::package_coverage())
