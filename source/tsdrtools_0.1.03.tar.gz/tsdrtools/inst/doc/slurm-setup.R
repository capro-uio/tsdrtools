## ---- include = FALSE---------------------------------------------------------
options(rmarkdown.html_vignette.check_title = FALSE)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
#  install.packages("clipr", lib = "/cluster/projects/pXXX/tools/r_libs/common")

## -----------------------------------------------------------------------------
#  library(clipr, lib.loc = "/cluster/projects/pXXX/tools/r_libs/common")

