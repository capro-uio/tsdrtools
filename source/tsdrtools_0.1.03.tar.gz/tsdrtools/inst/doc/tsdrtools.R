## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tsdrtools)

## ----eval = FALSE-------------------------------------------------------------
#  install.packages("remotes")
#  remotes::install_github("LCBC-UIO/tsdrtools")

## ----eval = FALSE-------------------------------------------------------------
#  install.packages("/path/to/tsdrtools.tar.gz", repo = NULL)

## ----prepare-package, eval = FALSE--------------------------------------------
#  library(tsdrtools)
#  
#  # outside TSD
#  tsd_package_prepare("dplyr")
#  
#  # within TSD
#  status <- tsd_package_prepare("dplyr.zip")

## ---- echo = FALSE------------------------------------------------------------
deps <- tsdrtools:::get_dependency_tree("dplyr", repos = "https://cran.rstudio.com/", verbose = FALSE)
pkgs <- as.data.frame(available.packages(repos = "https://cran.rstudio.com/" ))
pkgs <- pkgs[na.omit(match(deps, pkgs$Package)),c("Package", "Version")]

status <- list(
  success = data.frame(
    success = ifelse(pkgs$Package == "crayon", "failed", "success"),
    pkg = pkgs$Package,
    version =  pkgs$Version
  ),
  error_logs = list(
    crayon = c("The full build error", "will appear here.", "This is just a mock example")
  )
)

status <- as_tsdrtools_install(status)

## -----------------------------------------------------------------------------
# View install status
status

error_logs(status)

