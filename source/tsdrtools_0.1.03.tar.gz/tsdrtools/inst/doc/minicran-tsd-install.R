## ---- include = FALSE---------------------------------------------------------
options(rmarkdown.html_vignette.check_title = FALSE)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
#  install.packages("Y", repos = "https://cran.tsd.usit.no")

## -----------------------------------------------------------------------------
#  local({
#         r = getOption("repos")
#         r["CRAN"] <- "https://cran.tsd.usit.no"
#         r["BIOCONDUCTOR"] <- "https://bioconductor.tsd.usit.no"
#         r["BIOCONDUCTOR-annotation"] <- "https://bioconductor.tsd.usit.no/data/annotation"
#         r["BIOCONDUCTOR-experiment"] <- "https://bioconductor.tsd.usit.no/data/experiment"
#         r["BioC_mirror"] <- "https://bioconductor.tsd.usit.no"
#         options(repos=r)
#         options(BIOCONDUCTOR_ONLINE_VERSION_DIAGNOSIS = FALSE)
#         options(download.file.method = "libcurl")
#         })

## -----------------------------------------------------------------------------
#  configure: error: "libxml not found"

