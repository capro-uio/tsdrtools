## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tsdrtools)

## ----eval = FALSE-------------------------------------------------------------
#  install.packages("remotes")
#  remotes::install_github("LCBC-UIO/tsdrtools")

## ----eval = FALSE-------------------------------------------------------------
#  install.packages("/path/to/tsdrtools.tar.gz", repo = NULL)

## ----prepare-package, eval = FALSE--------------------------------------------
#  library(tsdrtools)
#  
#  # outside TSD
#  tsd_package_prepare("dplyr")
#  
#  # within TSD
#  tsd_package_prepare("dplyr.zip")

