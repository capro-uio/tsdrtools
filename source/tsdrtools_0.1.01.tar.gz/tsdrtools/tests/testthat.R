library(testthat)
library(tsdrtools)

test_check("tsdrtools")
