# tsdrtools 0.1.02
* New checks if install is complete by capture.output
* workaround for stringi package

# tsdrtools 0.1.01

* Added a `NEWS.md` file to track changes to the package.
* Installs are no longer checked by `installed.packages`but by catching errors during install  

