## ---- include = FALSE---------------------------------------------------------
options(rmarkdown.html_vignette.check_title = FALSE)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
#  library(tsdrtools)
#  tsd_package_prepare("tidyverse")

## -----------------------------------------------------------------------------
#  tsd_package_prepare("path/to/tidyverse.zip")

